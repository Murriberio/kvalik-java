import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.regex.Pattern;

public class ExcelLikeApp extends JFrame {
    private JTable dataTable;
    private DefaultTableModel tableModel;
    private JTextField nField, timeField, resultField;

    public ExcelLikeApp() {
        setTitle("Упрощённый Excel — Фиксация производительности");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        initComponents();
        setupKeyBindings();
    }

    private void initComponents() {
        // Модель таблицы
        tableModel = new DefaultTableModel(
                new Object[]{"ID", "Число N", "Время (сек)", "Получившееся число"}, 0
        );
        dataTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(dataTable);

        // Панель ввода данных
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Ввод данных"));

        inputPanel.add(new JLabel("Число N:"));
        nField = new JTextField();
        inputPanel.add(nField);

        inputPanel.add(new JLabel("Время (сек):"));
        timeField = new JTextField();
        timeField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (!Pattern.matches("[0-9.]", String.valueOf(e.getKeyChar()))) {
                    e.consume();
                }
            }
        });
        inputPanel.add(timeField);

        inputPanel.add(new JLabel("Получившееся число:"));
        resultField = new JTextField();
        inputPanel.add(resultField);

        // Панель кнопок
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton addButton = new JButton("Добавить");
        JButton deleteButton = new JButton("Удалить");
        JButton clearButton = new JButton("Очистить");

        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);

        // Обработчики событий
        addButton.addActionListener(e -> addRow());
        deleteButton.addActionListener(e -> deleteRow());
        clearButton.addActionListener(e -> clearFields());

        // Основной layout
        setLayout(new BorderLayout(10, 10));
        add(scrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);

        // Стилизация
        getRootPane().setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        applyCustomStyles();
    }

    private void applyCustomStyles() {
        getContentPane().setBackground(Color.WHITE);
        dataTable.setGridColor(Color.LIGHT_GRAY);
        dataTable.setRowHeight(25);
        dataTable.setFont(new Font("Arial", Font.PLAIN, 12));
    }

    private void setupKeyBindings() {
        dataTable.getInputMap(JComponent.WHEN_FOCUSED)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_BACK_SPACE, 0), "clear");
        dataTable.getActionMap().put("clear", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) { clearFields(); }
        });

        dataTable.getInputMap(JComponent.WHEN_FOCUSED)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0), "delete");
        dataTable.getActionMap().put("delete", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) { deleteRow(); }
        });

        dataTable.getInputMap(JComponent.WHEN_FOCUSED)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK), "add");
        dataTable.getActionMap().put("add", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) { addRow(); }
        });
    }

    private void addRow() {
        try {
            int n = Integer.parseInt(nField.getText());
            double time = Double.parseDouble(timeField.getText());
            int result = Integer.parseInt(resultField.getText());

            if (time < 0) {
                JOptionPane.showMessageDialog(this, "Время не может быть отрицательным!");
                return;
            }

            // Просто добавляем строку в таблицу
            tableModel.addRow(new Object[]{
                    tableModel.getRowCount() + 1, // ID как номер строки
                    n,
                    time,
                    result
            });

            clearFields();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Проверьте корректность введённых данных!");
        }
    }

    private void deleteRow() {
        int selectedRow = dataTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Выберите строку для удаления!");
            return;
        }

        tableModel.removeRow(selectedRow);
    }

    private void clearFields() {
        nField.setText("");
        timeField.setText("");
        resultField.setText("");
        dataTable.clearSelection();
        nField.requestFocusInWindow();
    }

    private void loadDataFromDB() {
        // Ничего не делаем — данных из БД нет
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                // Устанавливаем системный стиль оформления (если доступно)
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                // Игнорируем — используем стандартный стиль Swing
            }

            ExcelLikeApp app = new ExcelLikeApp();
            app.setVisible(true);
        });
    }
}
